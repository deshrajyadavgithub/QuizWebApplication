const questions = [
    {
        question: "What is the capital of France?",
        options: ["London", "Berlin", "Paris", "Rome"],
        answer: 2
    },
    {
        question: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        answer: 1
    },
    {
        question: "What is the capital of Japan?",
        options: ["Beijing", "Seoul", "Bangkok", "Tokyo"],
        answer: 3
    }
];

let currentQuestionIndex = 0;
let score = 0;

function loadQuestion() {
    const questionElement = document.getElementById('question');
    const options = document.querySelectorAll('.option-btn');
    const currentQuestion = questions[currentQuestionIndex];

    questionElement.textContent = currentQuestion.question;
    options.forEach((option, index) => {
        option.textContent = currentQuestion.options[index];
        option.style.backgroundColor = "#fff";
        option.style.color = "#333";
        option.disabled = false;
    });
    document.getElementById('next-btn').style.display = 'none';
    document.getElementById('score-display').textContent = `Score: ${score}`;
    updateProgressBar();
}

function selectOption(selectedIndex) {
    const options = document.querySelectorAll('.option-btn');
    const currentQuestion = questions[currentQuestionIndex];
    options.forEach((option, index) => {
        if (index === currentQuestion.answer) {
            option.style.backgroundColor = "#28a745";
            option.style.color = "#fff";
        }
        if (index === selectedIndex && index !== currentQuestion.answer) {
            option.style.backgroundColor = "#dc3545";
            option.style.color = "#fff";
        }
        option.disabled = true;
    });
    if (selectedIndex === currentQuestion.answer) {
        score++;
    }
    document.getElementById('next-btn').style.display = 'block';
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        showResults();
    }
}

function showResults() {
    const quizContainer = document.getElementById('quiz');
    quizContainer.innerHTML = `
        <h1>Quiz Completed</h1>
        <p>Your score is ${score} out of ${questions.length}</p>
        <button onclick="restartQuiz()">Restart Quiz</button>
    `;
}

function restartQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    document.getElementById('quiz').innerHTML = `
        <h1>Quiz App</h1>
        <div id="progress-bar"></div>
        <div class="question" id="question"></div>
        <ul class="options">
            <li><button class="option-btn" onclick="selectOption(0)"></button></li>
            <li><button class="option-btn" onclick="selectOption(1)"></button></li>
            <li><button class="option-btn" onclick="selectOption(2)"></button></li>
            <li><button class="option-btn" onclick="selectOption(3)"></button></li>
        </ul>
        <button id="next-btn" onclick="nextQuestion()">Next Question</button>
        <div id="score-display"></div>
    `;
    loadQuestion();
}

function updateProgressBar() {
    const progressBar = document.getElementById('progress-bar');
    const progressPercentage = ((currentQuestionIndex + 1) / questions.length) * 100;
    progressBar.style.width = `${progressPercentage}%`;
}

document.addEventListener('DOMContentLoaded', loadQuestion);
